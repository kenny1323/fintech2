const app = document.getElementById('root');



const container = document.createElement('div');
container.setAttribute('class', 'container');

app.appendChild(container);

var request = new XMLHttpRequest();
request.open('GET', 'https://jsonplaceholder.typicode.com/posts', true);
request.onload = function () {

  //GET JSON data here
  var data = JSON.parse(this.response);
  if (request.status >= 200 && request.status < 400) {
    data.forEach(retrieved_element => {
      const panel = document.createElement('div');
      panel.setAttribute('class', 'panel');

      const h1 = document.createElement('h1');
      h1.textContent = retrieved_element.title;

      const p = document.createElement('p');
      retrieved_element.body = retrieved_element.body.substring(0, 300);
      p.textContent = `${retrieved_element.body}...`;

      container.appendChild(panel);
      panel.appendChild(h1);
      panel.appendChild(p);
    });
  } else {
    const errorMessage = document.createElement('marquee');
    errorMessage.textContent = `GOT ERROR!`;
    app.appendChild(errorMessage);
  }
}

request.send();